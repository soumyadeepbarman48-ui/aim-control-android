AIM CONTROL — ANDROID PROJECT SOURCE

What it is:
- An offline, red-and-black Android companion app.
- Sensitivity notebook with editable sliders and local saving.
- A simple tap-target practice mini-game.
- Does not connect to, modify, or overlay Free Fire.

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Let Android Studio sync Gradle and install the Android SDK if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Requirements:
- Android Studio with JDK 17 support.
- Android SDK platform 35 (Android Studio can install it).
- Internet may be needed on first Gradle sync.

To install on your phone:
Transfer the APK to your Android phone, open it, and approve installation from that file source if Android asks.

Fair-play limits:
This is a standalone practice companion. It has no auto-headshot, auto-aim, injector,
game-memory editing, anti-cheat bypass, or game overlay. It cannot guarantee headshots.
